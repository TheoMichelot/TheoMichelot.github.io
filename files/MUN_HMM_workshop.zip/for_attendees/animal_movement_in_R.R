## ----install-package, eval = FALSE--------------------------------------------------------------------
## install.packages("momentuHMM")


## ----load-packages------------------------------------------------------------------------------------
# Load packages
library(momentuHMM)
library(ggplot2)
theme_set(theme_bw())
# Colour palette
pal <- c("#E69F00", "#56B4E9", "#009E73")

# Load elephant data (from Movebank; Slotow et al., 2019)
elephant_raw <- read.csv("data/elephant.csv")

# Plot elephant tracks
ggplot(elephant_raw, aes(x, y, col = ID)) +
    geom_path() +
    geom_point(size = 0.3) +
    coord_equal()


## ----prep-data1---------------------------------------------------------------------------------------
# Prepare data for HMM (compute step lengths and turning angles)
elephant_data <-prepData(elephant_raw, type = "UTM", covNames = "temp")

head(elephant_data, 10)


## ----fit-hmm1, results = 'hide', message = FALSE------------------------------------------------------
# Observation distributions
dist <- list(step = "gamma", angle = "vm")

# Initial parameters
# (step mean 1, step mean 2, step SD 1, step SD 2) and (angle concentration 1, angle concentration 2)
Par0_2s <- list(step = c(0.05, 0.2, 0.05, 0.2), angle = c(0.1, 3))

# Fit a 2-state HMM
elephant_hmm1 <- fitHMM(elephant_data, nbStates = 2, dist = dist, Par0 = Par0_2s)


## ----look-hmm1, fig.keep = 1:3------------------------------------------------------------------------
elephant_hmm1

plot(elephant_hmm1, breaks = 25, ask = FALSE)


## ----fit-hmm2, results = 'hide', message = FALSE------------------------------------------------------
# Initial parameters
Par0_3s <- list(step = c(0.02, 0.1, 0.3, 0.02, 0.1, 0.3), 
                angle = c(0.01, 0.1, 3))

# Fit 3-state HMM
elephant_hmm2 <- fitHMM(elephant_data, nbStates = 3, dist = dist, Par0 = Par0_3s)


## ----look-hmm2, fig.keep = 1:3------------------------------------------------------------------------
elephant_hmm2

plot(elephant_hmm2, breaks = 25, ask = FALSE)


## ----viterbi------------------------------------------------------------------------------------------
head(viterbi(elephant_hmm2))

elephant_data$state_2st <- factor(viterbi(elephant_hmm1))
elephant_data$state_3st <- factor(viterbi(elephant_hmm2))

ggplot(elephant_data, aes(x, y, col = state_2st, group = ID)) +
    geom_point(size = 0.5) + geom_path() +
    coord_equal() +
    scale_color_manual(values = pal, name = "state")
ggplot(elephant_data, aes(x, y, col = state_3st, group = ID)) +
    geom_point(size = 0.5) + geom_path() +
    coord_equal() +
    scale_color_manual(values = pal, name = "state")


## ----fit-hmm3, message = FALSE------------------------------------------------------------------------
# Fit 2-state HMM with temperature covariate (linear or quadratic effect)
elephant_hmm3 <- fitHMM(elephant_data, nbStates = 2, dist = dist, 
               Par0 = Par0_2s, formula = ~temp)
elephant_hmm4 <- fitHMM(elephant_data, nbStates = 2, dist = dist, 
               Par0 = Par0_2s, formula = ~temp+I(temp^2))

# Compare models using AIC
AIC(elephant_hmm3, elephant_hmm4)


## ----look-hmm3----------------------------------------------------------------------------------------
plot(elephant_hmm3, plotTracks = FALSE, ask = FALSE, plotCI = TRUE)


## ----plot-stationary----------------------------------------------------------------------------------
plotStationary(elephant_hmm3, plotCI = TRUE)


## ----pseudo-res, message = FALSE----------------------------------------------------------------------
plotPR(elephant_hmm1)
plotPR(elephant_hmm2)


## ----albatross-data-----------------------------------------------------------------------------------
# Load data file
albatross_raw <- read.csv("data/albatross.csv")
# Rename data columns
colnames(albatross_raw)[1:3] <- c("frequency_max", "acc_heave", "sd_heading")
# Subset to one individual for speed
albatross_raw <- subset(albatross_raw, ID == "GHAL44")
# Define time column for plots (in hours)
albatross_raw$time <- (1:nrow(albatross_raw)) / 2 / 60

# Take a look at data
head(albatross_raw)


## ----albatross-plot-data------------------------------------------------------------------------------
# Histogram of acceleration frequency
p1 <- ggplot(albatross_raw, aes(x = frequency_max)) +
    geom_histogram(aes(y = after_stat(density)), bins = 50, 
                   fill = "grey", col = "white") +
    labs(x = "frequency", y = "density")

# Time series plot of acceleration frequency
p2 <- ggplot(albatross_raw[1:1000,], aes(x = time, y = frequency_max)) +
    geom_line() +
    labs(x = "time (hours)", y = "frequency")

# Histogram of acceleration amplitude
p3 <- ggplot(albatross_raw, aes(x = acc_heave)) +
    geom_histogram(aes(y = after_stat(density)), bins = 50, 
                   fill = "grey", col = "white") +
    labs(x = "amplitude", y = "density")

# Time series plot of acceleration amplitude
p4 <- ggplot(albatross_raw, aes(x = time, y = acc_heave)) +
    geom_line() +
    labs(x = "time (hours)", y = "amplitude")

cowplot::plot_grid(p1, p2, p3, p4, ncol = 2)


## ----albatross-prep-----------------------------------------------------------------------------------
albatross_data <- prepData(albatross_raw, coordNames = NULL)


## ----albatross-model, message = FALSE-----------------------------------------------------------------
# Initial parameter values (mean1, mean2, mean3, SD1, SD2, SD3)
par0 <- list(acc_heave = c(1, 1.5, 1.5, 0.5, 1, 1.5),
             frequency_max = c(1, 3, 1, 1, 1, 1))

# Fit 3-state model
albatross_hmm <- fitHMM(data = albatross_data, 
                        nbStates = 3, 
                        dist = list(acc_heave = "norm", frequency_max = "gamma"), 
                        Par0 = par0)


## ----albatross-plot1----------------------------------------------------------------------------------
# Plot state-dependent distributions
plot(albatross_hmm, breaks = 25, ask = FALSE)


## ----albatross-plot2----------------------------------------------------------------------------------
# Get most likely state sequence
albatross_data$state <- factor(viterbi(albatross_hmm))

# Plot data coloured by states
ggplot(albatross_data, aes(time, frequency_max, col = state, group = NA)) +
    geom_point(size = 0.2) +
    scale_color_manual(values = pal) +
    labs(x = "time (hours)", y = "frequency")
ggplot(albatross_data, aes(time, acc_heave, col = state, group = NA)) +
    geom_point(size = 0.2) +
    scale_color_manual(values = pal) +
        labs(x = "time (hours)", y = "amplitude")

